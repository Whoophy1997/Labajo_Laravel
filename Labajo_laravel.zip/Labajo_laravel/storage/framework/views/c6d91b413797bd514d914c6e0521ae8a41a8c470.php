<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>

              <div class="panel panel-default">
              	<H5>
  				  I Am AZURA, RYAN ANDREW.<BR><BR>
  				  I am currently residing at Pitalo San Fernando, Cebu.<BR><BR>
  				  I am the youngest among 3 siblings.<BR><BR>
  				  I was born in Maydolong, Eastern Samar.<BR><BR>
  				  I am already married to Merlie Ladiao Azura for about 3 years.<BR><BR>
  				  I was able to work in  Japan for 3 years and because of that, I was able to experience the life in Japan.<BR><BR>
  				  Learn about thier culture and explore the beauty that is being offered in Japan.<BR><BR>
  				  And because of that as well, I was not able to finished my studies.<BR><BR>
  				  But because i firmly believed that education knows no boundaries,<BR><BR>
  				  and so I am here,striving to finish my studies so that i can have a better future,<BR><BR>
  				  not just for me but for my wife and for my future kids.<BR><BR>
  				  Hopefully I will be able to finish my studies this coming October.<BR><BR>
  				  As a professional in terms of work, I can proudly say that<BR><BR>
  				  I am able to work with speed, accuracy and can work under high pressure.<BR><BR>
  				  I am highly dedicated and persevering with a positive attitude.<BR><BR>
  				  I am trainable and able to work with less supervision.<BR><BR>
  				  I also possessed flexible personality, maturity and<BR><BR>
  				  I am able to work independently or as a part of a team.<BR><BR>
  				  Because of these reasons that I am confident that I can have a bright future ahead of me and<BR><BR>
  				  I am looking forward to the challenges that will go along the way.
              </H5>
              </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>