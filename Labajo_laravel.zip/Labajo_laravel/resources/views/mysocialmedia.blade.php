@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>Social Media</h3>s

              <div class="panel panel-default">
                <center>
          				Facebook: https://www.facebook.com/jeonhyunwhoophy<BR><BR>
            </center>
              </div>
            </div>
        </div>
    </div>
</div>
@stop