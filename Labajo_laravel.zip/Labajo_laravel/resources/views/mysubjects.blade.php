﻿@extends('layouts.app2')

@section("content")
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">   
          <h3>Subject</h3>
              <div class="panel panel-default">
              	<table style="width:100%" border="1">
				  <tr>
				    <th>Subject Name</th>
				    <th>Days & Time</th> 
				    <th>Teacher</th>
				  </tr>
				  <tr>
				  <td>ITPHP2</td>
				  <td>MWF - 6:30 - 8:30 </td> 
				  <td>Mr. Gian Carlo Cataraja</td>
				  </tr>
				  <tr>
				    <td>FREELPM</td>
				    <td>TTH - 8:00 - 9:30</td>
				    <td>Theodoro Marvin Avergonzado Jr.</td>
				  </tr>
				 
				</table>
              </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
@stop