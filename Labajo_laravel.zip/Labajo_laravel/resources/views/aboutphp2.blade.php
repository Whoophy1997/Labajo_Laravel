@extends('layouts.app2')

@section("content")
  <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	 <h3>About PHP-2</h3>
           <center>
              <div class="panel panel-default">
              	This subject is focused when it comes to interacting frameworks especially the object oriented programming. Right now were using Laravel framework<BR><BR>
            </div>
              </center>
            </div>
        </div>
    </div>
</div>
@stop