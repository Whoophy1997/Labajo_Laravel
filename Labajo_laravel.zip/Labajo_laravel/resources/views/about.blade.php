@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>About</h3>

              <div class="panel panel-default">
                <center>
              
        				  My name is Whoophy John A. Labajo<BR><BR>
        				  My hometown is in Camotes, Cansabusab, Poro, Cebu<BR><BR>
        				  I'm the the elsest son of our family<BR><BR>
        				  I was born in MCCH<BR><BR>
        				  My mother supports me with my studies.<BR><BR>
        				  My latest part time job is an ESL Teacher at Linguage<BR><BR>
        				  I'm currently a 4th year College Student.<BR><BR>
        				  I am studyin at University of Cebu Main.<BR><BR>
        				  Hopefully I will make and graduate with this course's bachelor degree.<BR><BR>
        				  I love music.<BR><BR>
        				  I can sing and dance.<BR><BR>
        				  I love travelling.<BR><BR>
        				  I like to travel all around the world<BR><BR>
        				  I like to work in lined with my course<BR><BR>
        				  I am simple but with principles.<BR><BR>
        				  My dream is to become a Singer.<BR><BR>
        				  My goal in life is to obtain this bachelor degree.<BR><BR>
        				
              
              </center>
              </div>
            </div>
        </div>
    </div>
</div>

@stop